/**
 * ymm-bridge 前端扩展
 * ------------------------------------------------------------------
 * 当页面带 ?ymm_gallery=<作品ID>&ymm_site=<站点地址> 打开时自动执行：
 *   1. 通过本地 /ymm/payload 代理拉取作品数据（工作流 + 模型清单）
 *   2. 逐个下载缺失模型进 ComfyUI 的 models/<dir>/
 *   3. 把工作流加载进画布并自动排队出图
 *
 * 网盘类来源（quark/netdisk/...）不自动下载，需用户手动点链接下载后放进 models。
 */
import { app } from "../../scripts/app.js";

const NETDISK_TYPES = new Set(["quark", "netdisk", "baidu", "aliyun", "pan"]);

function banner(text, kind = "info") {
  let el = document.getElementById("ymm-bridge-banner");
  if (!el) {
    el = document.createElement("div");
    el.id = "ymm-bridge-banner";
    el.style.cssText = [
      "position:fixed",
      "left:50%",
      "top:16px",
      "transform:translateX(-50%)",
      "z-index:99999",
      "max-width:80vw",
      "padding:10px 16px",
      "border-radius:10px",
      "font-size:13px",
      "line-height:1.5",
      "color:#fff",
      "box-shadow:0 8px 24px rgba(0,0,0,.28)",
      "transition:opacity .2s ease",
    ].join(";");
    document.body.appendChild(el);
  }
  const bg =
    kind === "error" ? "#b91c1c" : kind === "success" ? "#15803d" : "#1f2937";
  el.style.background = bg;
  el.textContent = text;
  if (kind === "success") {
    setTimeout(() => el && el.remove(), 5000);
  }
}

async function fetchPayload(galleryId, site) {
  const url = `/ymm/payload?gallery_id=${encodeURIComponent(
    galleryId
  )}&site=${encodeURIComponent(site || "")}`;
  const resp = await fetch(url);
  return resp.json();
}

async function downloadModel(source) {
  const resp = await fetch("/ymm/download", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      url: source.url,
      name: source.name,
      dir: source.dir || "checkpoints",
      sha256: source.sha256 || "",
    }),
  });
  return resp.json();
}

async function run() {
  const params = new URLSearchParams(window.location.search);
  const galleryId = params.get("ymm_gallery");
  const site = params.get("ymm_site");
  if (!galleryId) return;

  banner("一幕AI：正在拉取作品数据…");
  const json = await fetchPayload(galleryId, site);
  if (!json || json.success === false || !json.data) {
    banner(`拉取失败：${(json && json.message) || "未知错误"}`, "error");
    return;
  }
  const payload = json.data;

  const autoModels = (payload.model_sources || []).filter(
    (m) => m.url && !NETDISK_TYPES.has(String(m.type || "").toLowerCase())
  );
  const netdiskModels = (payload.model_sources || []).filter((m) =>
    NETDISK_TYPES.has(String(m.type || "").toLowerCase())
  );

  for (const source of autoModels) {
    banner(`下载模型 ${source.name || source.url} …`);
    try {
      const result = await downloadModel(source);
      if (!result.success) {
        banner(`模型下载失败：${result.message || source.name}`, "error");
      }
    } catch (err) {
      banner(`模型下载异常：${err}`, "error");
    }
  }

  if (netdiskModels.length > 0) {
    banner(
      `有 ${netdiskModels.length} 个模型在网盘，请回站点手动下载后放进 models 目录。`,
      "info"
    );
  }

  if (!payload.workflow_json) {
    banner("该作品未配置工作流，无法自动生图。", "error");
    return;
  }

  banner("加载工作流…");
  let workflow;
  try {
    workflow = JSON.parse(payload.workflow_json);
  } catch (err) {
    banner("工作流 JSON 解析失败。", "error");
    return;
  }

  // 等画布初始化完成再载入，避免 setup 阶段 app 还未就绪
  await new Promise((resolve) => setTimeout(resolve, 300));
  await app.loadGraphData(workflow);
  banner("工作流已加载，正在排队出图…");
  app.queuePrompt(0, 1);
  banner("已提交出图 ✅", "success");
}

app.registerExtension({
  name: "ymm.bridge",
  async setup() {
    try {
      await run();
    } catch (err) {
      banner(`ymm-bridge 执行失败：${err}`, "error");
    }
  },
});

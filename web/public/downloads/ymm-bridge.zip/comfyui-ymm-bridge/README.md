# ymm-bridge · 一幕AI 画廊 → 本地 ComfyUI 一键生图

把「一幕AI」(cdymm.com) 提示词画廊里的作品，一键还原到**你自己电脑上的 ComfyUI**：
自动拉工作流、自动下模型、自动排队出图。

> 原理：画廊详情页的「去创作」会打开
> `http://127.0.0.1:8188/?ymm_gallery=<作品ID>&ymm_site=https://cdymm.com`。
> 本节点自带前端扩展，读到这两个参数后完成后续动作。全程不出本机（只有拉取
> 作品数据与模型文件是联网的）。

## 安装

下载地址：<https://cdymm.com/comfyui>（页面上的「下载节点」按钮给的就是下面这个 zip）。

1. 把 zip 解压出的 `comfyui-ymm-bridge/` 整个目录，放进你的 ComfyUI 目录：

   ```
   ComfyUI/custom_nodes/comfyui-ymm-bridge/
   ```

   解压后应该是 `custom_nodes/comfyui-ymm-bridge/__init__.py`，
   **不要**多套一层（`comfyui-ymm-bridge/comfyui-ymm-bridge/__init__.py` 会加载不到）。

2. 重启 ComfyUI。启动日志里出现 `ymm-bridge` 即加载成功。

3. 打开画廊详情页，点「**ComfyUI 一键生图**」。浏览器会新开一个标签页指向
   `http://127.0.0.1:8188/?ymm_gallery=...`，随后自动开始下载模型并出图。

卸载：删掉 `custom_nodes/comfyui-ymm-bridge/` 目录即可，不影响已下载的模型与既有工作流。

## 它做了什么

| 步骤 | 说明 |
|---|---|
| 拉数据 | `GET /ymm/payload` 代理请求站点 `GET /api/prompt-gallery/v1/prompts/:id/create`（绕开浏览器跨域） |
| 下模型 | `POST /ymm/download` 把缺失模型流式写进 `models/<dir>/`，已存在则跳过，支持 sha256 校验 |
| 载工作流 | 前端 `app.loadGraphData(workflow)` 还原节点图 |
| 出图 | `app.queuePrompt(0, 1)` 自动排队 |

## 工作流格式（重要）

站点里作品的 `workflow_json` **必须是 ComfyUI 的 UI 格式**——也就是在 ComfyUI 里
「Save / 保存」出来的那份完整节点图 JSON（含 `nodes`、`links`）。API 格式
（`prompt` 格式，只有节点 id → inputs）无法还原成画布，只能 POST 给 `/prompt`。

## 模型来源约定

站点作品的 `model_sources` 是数组，每项：

```json
{
  "type": "huggingface",          // huggingface / civitai / oss / quark / netdisk ...
  "name": "xxlbase_v1.safetensors",
  "url": "https://.../xxlbase_v1.safetensors",
  "dir": "checkpoints",            // ComfyUI/models 下的子目录
  "sha256": "可选"
}
```

- `type` 为 `quark` / `netdisk` / `baidu` / `aliyun` / `pan` → **不自动下载**
  （网盘需登录态且免费限速），前端会提示用户回站点手动下载。
- 其余类型（huggingface / civitai / oss…）→ 节点自动下载到 `models/<dir>/`。

## 已知限制

- 需要 ComfyUI 在默认端口 `8188` 启动；改了端口需自行调整站点「去创作」打开的地址。
- 自定义节点只用 Python 标准库 + `aiohttp`（ComfyUI 自带），无需额外 pip 安装。
- 目前是「下载完直接排队」，尚未做下载进度条与失败重试 UI（后续可加）。

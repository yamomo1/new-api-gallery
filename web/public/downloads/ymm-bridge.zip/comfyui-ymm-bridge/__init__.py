"""
ymm-bridge：一幕AI 提示词画廊 → 本地 ComfyUI 一键生图
================================================================

安装
----
把这个目录放进 ComfyUI 的 custom_nodes：

    ComfyUI/custom_nodes/comfyui-ymm-bridge/

重启 ComfyUI 即生效（自带前端扩展，无需在节点图里连线）。

使用
----
在画廊详情页点「ComfyUI 一键生图」，会打开：

    http://127.0.0.1:8188/?ymm_gallery=<作品ID>&ymm_site=https://cdymm.com

本节点会自动：
  1. 从站点拉取该作品的工作流与模型清单（服务端代理，绕开 CORS）
  2. 把缺失模型下载进 ComfyUI 的 models/<dir>/（网盘类来源跳过，需手动下载）
  3. 把工作流加载进画布并自动排队出图

工作流格式约定
--------------
站点里的 workflow_json 必须是 ComfyUI **UI 格式**（ComfyUI 里「Save」出来的
那份完整节点图 JSON，含 nodes/links），这样才能被 `app.loadGraphData()` 还原。
API 格式（prompt 格式）无法直接还原成画布。
"""

import hashlib
import os
import re

import aiohttp
from aiohttp import web
from server import PromptServer

try:
    import folder_paths  # ComfyUI 内置模块
except Exception:  # pragma: no cover - 仅在非 ComfyUI 环境导入失败
    folder_paths = None

NODE_CLASS_MAPPINGS = {}
NODE_DISPLAY_NAME_MAPPINGS = {}
WEB_DIRECTORY = "./web"

routes = PromptServer.instance.routes

# 网盘类来源不自动下载（需要登录态 / 限速），由用户手动点链接
_NETDISK_TYPES = {"quark", "netdisk", "baidu", "aliyun", "pan"}

_SAFE_NAME = re.compile(r"[^0-9A-Za-z._\-]+")


def _sanitize_filename(name: str, fallback: str) -> str:
    name = (name or "").strip().replace("\\", "/").split("/")[-1]
    name = _SAFE_NAME.sub("_", name)
    return name or fallback


def _models_root() -> str:
    if folder_paths is not None:
        return folder_paths.models_dir
    # 兜底：ComfyUI/models（相对 custom_nodes 的两级上）
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.abspath(os.path.join(here, "..", "..", "models"))


def _target_dir(dir_name: str) -> str:
    dir_name = (dir_name or "checkpoints").strip().replace("\\", "/")
    dir_name = "/".join(p for p in dir_name.split("/") if p and p != "..")
    path = os.path.join(_models_root(), dir_name)
    os.makedirs(path, exist_ok=True)
    return path


@routes.get("/ymm/payload")
async def ymm_payload(request: web.Request) -> web.Response:
    """代理拉取站点的「去创作」数据包，避免浏览器跨域限制。"""
    gallery_id = request.query.get("gallery_id", "").strip()
    site = request.query.get("site", "").strip().rstrip("/")
    if not gallery_id.isdigit() or not site:
        return web.json_response(
            {"success": False, "message": "missing or invalid gallery_id / site"},
            status=400,
        )
    url = f"{site}/api/prompt-gallery/v1/prompts/{gallery_id}/create"
    try:
        timeout = aiohttp.ClientTimeout(total=30)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(url) as resp:
                data = await resp.json(content_type=None)
        return web.json_response(data)
    except Exception as exc:  # pragma: no cover - 网络异常
        return web.json_response(
            {"success": False, "message": f"fetch payload failed: {exc}"}, status=502
        )


@routes.post("/ymm/download")
async def ymm_download(request: web.Request) -> web.Response:
    """把一个模型文件下载进 ComfyUI 的 models/<dir>/。"""
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"success": False, "message": "invalid json"}, status=400)

    url = (body.get("url") or "").strip()
    if not url.startswith(("http://", "https://")):
        return web.json_response({"success": False, "message": "invalid url"}, status=400)

    fallback = url.split("?")[0].rstrip("/").split("/")[-1] or "model.bin"
    filename = _sanitize_filename(body.get("name"), fallback)
    target_dir = _target_dir(body.get("dir") or "checkpoints")
    dest = os.path.join(target_dir, filename)

    if os.path.exists(dest) and os.path.getsize(dest) > 0:
        return web.json_response({"success": True, "skipped": True, "path": dest})

    tmp = dest + ".part"
    sha256 = hashlib.sha256()
    try:
        timeout = aiohttp.ClientTimeout(total=None, sock_read=300)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(url) as resp:
                resp.raise_for_status()
                with open(tmp, "wb") as fh:
                    async for chunk in resp.content.iter_chunked(1024 * 1024):
                        fh.write(chunk)
                        sha256.update(chunk)
        os.replace(tmp, dest)
    except Exception as exc:  # pragma: no cover - 下载异常
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass
        return web.json_response(
            {"success": False, "message": f"download failed: {exc}"}, status=502
        )

    expected = (body.get("sha256") or "").strip().lower()
    if expected and sha256.hexdigest().lower() != expected:
        return web.json_response(
            {"success": False, "message": "sha256 mismatch"}, status=409
        )

    return web.json_response({"success": True, "path": dest})


__all__ = ["NODE_CLASS_MAPPINGS", "NODE_DISPLAY_NAME_MAPPINGS", "WEB_DIRECTORY"]
